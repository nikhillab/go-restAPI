# simple-REST

Clone this repository into your go home path or a separate directory.

> Note: If you are making clone in a separate directory then you have to export your environments.


Step -2

Follow the steeps to install dependencies and run the project.
> glide install

This command will install all the respected dependencies in to your local vendor.

step -3

Go to your cmd/main directory and enter the following command

> go run main.go

This command will run the project successfully. 
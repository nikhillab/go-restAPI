package sqlite

import _ "github.com/mattn/go-sqlite3"
